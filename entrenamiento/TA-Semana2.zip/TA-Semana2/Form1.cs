﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TA_Semana2.controllers;
using TA_Semana2.entities;

namespace TA_Semana2
{
    public partial class Form1 : Form
    {
        private CAnimalController animalController = new CAnimalController();
        public Form1()
        {
            InitializeComponent();
        }
        private void MostrarDataGrid(CAnimal[] animales )
        {
            dgAnimales.DataSource = null;
            dgAnimales.DataSource = animales;

        }
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbCodigo.Text == "" || tbNombre.Text == "" || tbPeso.Text == "" || tbEdad.Text == "" || cbEspecie.Text == "")
            {
                MessageBox.Show("Ingreses todos los campos");
                return;
            }
            //Crear el objeto
            CAnimal animal = new CAnimal()
            {
                codigo = tbCodigo.Text,
                nombre = tbNombre.Text,
                especie = cbEspecie.Text,
                peso = double.Parse(tbPeso.Text),
                edad = int.Parse(tbEdad.Text),
            };
            //Registrar
            animalController.Registrar(animal);
            //Mostrar en el DataGrid
            MostrarDataGrid(animalController.ListarTodo());
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (dgAnimales.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione registro a eliminar");
                return;
            }
            if (tbCodigo.Text == "" || tbNombre.Text == "" || tbPeso.Text == "" || tbEdad.Text == "" || cbEspecie.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }
            // Obtener el código del animal seleccionado
            String codigoSeleccionado = dgAnimales.SelectedRows[0].Cells[0].Value.ToString();
            // Crear objeto con datos modificados (el código debe ser el mismo para identificar el registro)
            CAnimal animalModificado = new CAnimal()
            {
                codigo = codigoSeleccionado,
                nombre = tbNombre.Text,
                especie = cbEspecie.Text,
                peso = double.Parse(tbPeso.Text),
                edad = int.Parse(tbEdad.Text),
            };
            // Llamar a modificar en el controlador
            animalController.Modificar(animalModificado);
            // Refrescar DataGrid
            MostrarDataGrid(animalController.ListarTodo());

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if(dgAnimales.SelectedRows.Count==0)
            {
                MessageBox.Show("Seleccione registro a eliminar");
                return;
            }
            String codigo = dgAnimales.SelectedRows[0].Cells[0].Value.ToString();

            animalController.Eliminar(codigo);

            MostrarDataGrid(animalController.ListarTodo());
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
