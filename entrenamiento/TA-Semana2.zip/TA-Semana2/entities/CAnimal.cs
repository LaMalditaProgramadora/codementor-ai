﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TA_Semana2.entities
{
    internal class CAnimal
    {
        public String codigo { get; set; }
        public String nombre { get; set; }
        public String especie { get; set; }
        public double peso {  get; set; }
        public int edad {  get; set; }

    }
}
