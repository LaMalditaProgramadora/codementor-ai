﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TA_Semana2.entities;

namespace TA_Semana2.controllers
{
    internal class CAnimalController
    {
        private CAnimal[] animales = new CAnimal[100];
        private int cont = 0;

        public CAnimal[] ListarTodo()
        {
            return animales;
        }
        public void Registrar(CAnimal animal)
        {
            animales[cont] = animal;
            cont++;
        }
        public void Eliminar(String codigo)
        {
            int pos=Array.FindIndex(animales,animal=>animal.codigo.Equals(codigo));

            for(int i = 0; i < cont; i++)
            {
                if(i>=pos)
                {
                    animales[i]=animales[i+1];
                }
                cont--;
            }
        }
        public void Modificar(CAnimal animalModificado)
        {
            int pos = Array.FindIndex(animales, animal => animal != null && animal.codigo.Equals(animalModificado.codigo));
            if (pos >= 0)
            {
                animales[pos] = animalModificado;
            }
        }

    }
}
